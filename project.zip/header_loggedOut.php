  <body>
  <div id="wrapper">
<header>
  <div id="head_logo"></div>
  <div id="searchbox">
  <form action="search.php" method="post">
  <input type="text" name="search" id="search" value="Search keyword...">
  <input type="submit" id="submit_search" value="Go">
  </form>
  </div>
  <div id="header_nav">
  <a href="login.php">Log In</a>
  <a href="account.php">Sign Up</a>
  <a href="cart.php">View Cart</a>
  
  </div>
  </header>
  <nav>
  <ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="shop.php">Shop Cigars</a></li>
   <li><a href="login.php">Past Purchases</a></li>
 <li><a href="location.php">Location</a></li>
  </ul>
  </nav>
  <main>