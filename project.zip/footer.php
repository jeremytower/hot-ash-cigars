 </main>
  <footer>Copyright Hot Ash Cigars 2017 Jeremy_Tower</footer>
  </div>
   </body>
</html>
