<?php

$servername ="localhost";
$username ="tower476_all";
$password ="March123";
$dbname ="tower476_cigar";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn){
	die("connection failed: " . mysqli_connect_error());
}
?>