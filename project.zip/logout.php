<?/*DESTROYS THE SESSION, REDIRECTS TO INDEX.PHP*/
session_start();
session_unset();
session_destroy();

header("location: index.php");
exit();
?>